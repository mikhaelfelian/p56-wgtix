<?php

/**
 * @description Transaction management controller for admin panel - handles order management, status updates, and reporting
 * @author CodeIgniter Development Team
 * @since 2025-01-15
 * @version 1.0.0
 */

namespace App\Controllers\Admin\Transaksi;

use App\Controllers\BaseController;
use App\Models\TransJualModel;
use App\Models\TransJualDetModel;
use App\Models\TransJualPlatModel;
use CodeIgniter\HTTP\ResponseInterface;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use App\Libraries\InvoicePdf;
use App\Libraries\TicketPdf;
use App\Libraries\DotMatrixInvoicePdf;

class Sale extends BaseController
{
    protected $transJualModel;
    protected $transJualDetModel;
    protected $transJualPlatModel;
    protected $ionAuth;

    public function __construct()
    {
        $this->transJualModel = new TransJualModel();
        $this->transJualDetModel = new TransJualDetModel();
        $this->transJualPlatModel = new TransJualPlatModel();
        $this->ionAuth = new \IonAuth\Libraries\IonAuth();
    }

    /**
     * Display transaction orders with filtering by status
     */
    public function orders($status = 'all')
    {

        // Build query conditions for the model
        if ($status !== 'all') {
            $validStatuses = ['pending', 'paid', 'failed', 'cancelled'];
            if (in_array($status, $validStatuses)) {
                $this->transJualModel->where('payment_status', $status);
            }
        }

        // Get orders with pagination
        $this->transJualModel->orderBy('invoice_date', 'DESC');
        $orders = $this->transJualModel->paginate(20);
        $pager = $this->transJualModel->pager;

        // Get statistics for status filter buttons using fresh model instances
        $statsModel = new TransJualModel();
        $stats = [
            'all' => $statsModel->countAll(),
            'pending' => $statsModel->where('payment_status', 'pending')->countAllResults(false),
            'paid' => $statsModel->where('payment_status', 'paid')->countAllResults(false),
            'failed' => $statsModel->where('payment_status', 'failed')->countAllResults(false),
            'cancelled' => $statsModel->where('payment_status', 'cancelled')->countAllResults(false),
        ];

        $data = [
            'title' => 'Transaction Management',
            'orders' => $orders,
            'pager' => $pager,
            'current_status' => $status,
            'stats' => $stats
        ];

        return $this->view('admin-lte-3/transaksi/sale/orders', $data);
    }

    /**
     * Display transaction detail
     */
    public function detail($invoiceId)
    {

        // Get order details
        $order = $this->transJualModel->find($invoiceId);
        
        if (!$order) {
            session()->setFlashdata('error', 'Order not found');
            return redirect()->to('admin/transaksi/sale/orders');
        }

        // Get order items
        $order_details = $this->transJualDetModel->where('id_penjualan', $invoiceId)->findAll();

        // Get payment platforms
        $payment_platforms = $this->transJualPlatModel->where('id_penjualan', $invoiceId)->findAll();

        // Get user info using IonAuth
        $user = null;
        if ($order->user_id) {
            $user = $this->ionAuth->user($order->user_id)->row();
        }

        $data = [
            'title' => 'Transaction Detail - Invoice #' . $order->invoice_no,
            'order' => $order,
            'order_details' => $order_details,
            'payment_platforms' => $payment_platforms,
            'user' => $user
        ];

        return $this->view('admin-lte-3/transaksi/sale/detail', $data);
    }

    /**
     * Update order status
     */
    public function updateStatus($invoiceId)
    {
        $order = $this->transJualModel->find($invoiceId);
        
        if (!$order) {
            session()->setFlashdata('error', 'Order not found');
            return redirect()->to('admin/transaksi/sale/orders');
        }

        $newPaymentStatus = $this->request->getPost('payment_status');
        $newOrderStatus = $this->request->getPost('order_status');
        
        $updateData = [
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($newPaymentStatus) {
            $updateData['payment_status'] = $newPaymentStatus;
        }

        if ($newOrderStatus) {
            $updateData['status'] = $newOrderStatus;
        }

        if ($this->transJualModel->update($invoiceId, $updateData)) {
            // Generate QR codes for order details if payment status changed to 'paid'
            if ($newPaymentStatus === 'paid' && $order->payment_status !== 'paid') {
                $this->generateQRCodesForOrder($invoiceId);
            }
            
            session()->setFlashdata('success', 'Order status updated successfully');
        } else {
            session()->setFlashdata('error', 'Failed to update order status');
        }

        return redirect()->to('admin/transaksi/sale/detail/' . $invoiceId);
    }

    /**
     * Generate sales reports
     */
    public function reports()
    {
        // Get date range from request
        $startDate = $this->request->getGet('start_date') ?: date('Y-m-01');
        $endDate = $this->request->getGet('end_date') ?: date('Y-m-t');

        // Get sales data
        $builder = $this->transJualModel->builder();
        $builder->where('invoice_date >=', $startDate);
        $builder->where('invoice_date <=', $endDate . ' 23:59:59');
        $orders = $builder->orderBy('invoice_date', 'DESC')->get()->getResult();

        // Calculate statistics
        $totalOrders = count($orders);
        $totalRevenue = array_sum(array_column($orders, 'total_amount'));
        $paidOrders = array_filter($orders, function($order) {
            return $order->payment_status === 'paid';
        });
        $paidRevenue = array_sum(array_column($paidOrders, 'total_amount'));

        $data = [
            'title' => 'Sales Reports',
            'orders' => $orders,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'stats' => [
                'total_orders' => $totalOrders,
                'total_revenue' => $totalRevenue,
                'paid_orders' => count($paidOrders),
                'paid_revenue' => $paidRevenue,
                'pending_orders' => $totalOrders - count($paidOrders),
                'pending_revenue' => $totalRevenue - $paidRevenue
            ]
        ];

        return $this->view('admin-lte-3/transaksi/sale/reports', $data);
    }

    /**
     * Export transaction data
     */
    public function export($format = 'csv')
    {
        // Get date range from request
        $startDate = $this->request->getGet('start_date') ?: date('Y-m-01');
        $endDate = $this->request->getGet('end_date') ?: date('Y-m-t');

        // Get sales data
        $builder = $this->transJualModel->builder();
        $builder->where('invoice_date >=', $startDate);
        $builder->where('invoice_date <=', $endDate . ' 23:59:59');
        $orders = $builder->orderBy('invoice_date', 'DESC')->get()->getResult();

        if ($format === 'csv') {
            // Generate CSV export
            $filename = 'sales_export_' . date('Y-m-d_H-i-s') . '.csv';
            
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            
            $output = fopen('php://output', 'w');
            
            // CSV headers
            fputcsv($output, [
                'Invoice No',
                'Invoice Date',
                'Customer',
                'Payment Method',
                'Payment Status',
                'Order Status',
                'Total Amount',
                'Created At'
            ]);
            
            // CSV data
            foreach ($orders as $order) {
                // Get customer name using IonAuth
                $customerName = 'Guest User';
                if ($order->user_id) {
                    $user = $this->ionAuth->user($order->user_id)->row();
                    if ($user) {
                        $customerName = $user->first_name . ' ' . $user->last_name . ' (' . $user->username . ')';
                    } else {
                        $customerName = 'User ID: ' . $order->user_id;
                    }
                }
                
                fputcsv($output, [
                    $order->invoice_no,
                    $order->invoice_date,
                    $customerName,
                    $order->payment_method,
                    $order->payment_status,
                    $order->status,
                    $order->total_amount,
                    $order->created_at
                ]);
            }
            
            fclose($output);
            exit;
        }

        // Default to redirect if format not supported
        session()->setFlashdata('error', 'Export format not supported');
        return redirect()->to('admin/transaksi/sale/reports');
    }

    /**
     * Generate and download invoice PDF
     */
    public function downloadInvoice($invoiceId)
    {
        // Get order details
        $order = $this->transJualModel->find($invoiceId);
        
        if (!$order) {
            session()->setFlashdata('error', 'Order not found');
            return redirect()->to('admin/transaksi/sale/orders');
        }

        // Get order items
        $orderDetails = $this->transJualDetModel->where('id_penjualan', $invoiceId)->findAll();

        // Get payment platforms
        $paymentPlatforms = $this->transJualPlatModel->where('id_penjualan', $invoiceId)->findAll();

        // Get user info using IonAuth
        $user = null;
        if ($order->user_id) {
            $user = $this->ionAuth->user($order->user_id)->row();
        }

        try {
            // Create PDF instance
            $pdf = new InvoicePdf($order, $orderDetails, $paymentPlatforms, $user);
            
            // Generate PDF content
            $pdfContent = $pdf->generateInvoice();
            
            // Set headers for PDF download
            $filename = 'Invoice_' . $order->invoice_no . '_' . date('Y-m-d') . '.pdf';
            
            return $this->response
                ->setHeader('Content-Type', 'application/pdf')
                ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
                ->setHeader('Cache-Control', 'private, max-age=0, must-revalidate')
                ->setHeader('Pragma', 'public')
                ->setBody($pdfContent);
                
        } catch (\Exception $e) {
            log_message('error', 'PDF generation failed for invoice ' . $invoiceId . ': ' . $e->getMessage());
            session()->setFlashdata('error', 'Failed to generate PDF invoice: ' . $e->getMessage());
            return redirect()->to('admin/transaksi/sale/detail/' . $invoiceId);
        }
    }

    /**
     * Generate and download dot matrix style invoice PDF
     */
    public function downloadDotMatrixInvoice($invoiceId)
    {
        // Get order details
        $order = $this->transJualModel->find($invoiceId);
        
        if (!$order) {
            session()->setFlashdata('error', 'Order not found');
            return redirect()->to('admin/transaksi/sale/orders');
        }

        // Get order items
        $orderDetails = $this->transJualDetModel->where('id_penjualan', $invoiceId)->findAll();

        // Get payment platforms
        $paymentPlatforms = $this->transJualPlatModel->where('id_penjualan', $invoiceId)->findAll();

        // Get user info using IonAuth
        $user = null;
        if ($order->user_id) {
            $user = $this->ionAuth->user($order->user_id)->row();
        }

        try {
            // Create dot matrix PDF instance
            $pdf = new DotMatrixInvoicePdf($order, $orderDetails, $paymentPlatforms, $user);
            
            // Generate PDF content
            $pdfContent = $pdf->generateInvoice();
            
            // Set headers for PDF download
            $filename = 'DotMatrix_Invoice_' . $order->invoice_no . '_' . date('Y-m-d') . '.pdf';
            
            return $this->response
                ->setHeader('Content-Type', 'application/pdf')
                ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
                ->setHeader('Cache-Control', 'private, max-age=0, must-revalidate')
                ->setHeader('Pragma', 'public')
                ->setBody($pdfContent);
                
        } catch (\Exception $e) {
            log_message('error', 'Dot matrix PDF generation failed for invoice ' . $invoiceId . ': ' . $e->getMessage());
            session()->setFlashdata('error', 'Failed to generate dot matrix invoice: ' . $e->getMessage());
            return redirect()->to('admin/transaksi/sale/detail/' . $invoiceId);
        }
    }

    /**
     * Generate and download ticket PDF for a specific order detail
     */
    public function downloadTicket($orderDetailId)
    {
        // Get order detail
        $orderDetail = $this->transJualDetModel->find($orderDetailId);
        
        if (!$orderDetail) {
            session()->setFlashdata('error', 'Ticket not found');
            return redirect()->to('admin/transaksi/sale/orders');
        }

        // Get main order
        $order = $this->transJualModel->find($orderDetail->id_penjualan);
        
        if (!$order) {
            session()->setFlashdata('error', 'Order not found');
            return redirect()->to('admin/transaksi/sale/orders');
        }

        // Get user info using IonAuth
        $user = null;
        if ($order->user_id) {
            $user = $this->ionAuth->user($order->user_id)->row();
        }

        // Get event info (placeholder - you can expand this based on your event model)
        $event = (object)[
            'title' => $orderDetail->event_title ?: 'Event',
            'date' => $order->invoice_date,
            'location' => 'Event Venue'
        ];

        try {
            // Create ticket PDF instance
            $ticket = new TicketPdf($orderDetail, $order, $user, $event);
            
            // Generate ticket content
            $ticketContent = $ticket->generateTicket();
            
            // Set headers for PDF download
            $filename = 'Ticket_' . str_pad($orderDetail->id, 6, '0', STR_PAD_LEFT) . '_' . date('Y-m-d') . '.pdf';
            
            return $this->response
                ->setHeader('Content-Type', 'application/pdf')
                ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
                ->setHeader('Cache-Control', 'private, max-age=0, must-revalidate')
                ->setHeader('Pragma', 'public')
                ->setBody($ticketContent);
                
        } catch (\Exception $e) {
            log_message('error', 'Ticket generation failed for order detail ' . $orderDetailId . ': ' . $e->getMessage());
            session()->setFlashdata('error', 'Failed to generate ticket: ' . $e->getMessage());
            return redirect()->to('admin/transaksi/sale/detail/' . $orderDetail->id_penjualan);
        }
    }

    /**
     * Generate and download all tickets for an order
     */
    public function downloadAllTickets($invoiceId)
    {
        // Get order
        $order = $this->transJualModel->find($invoiceId);
        
        if (!$order) {
            session()->setFlashdata('error', 'Order not found');
            return redirect()->to('admin/transaksi/sale/orders');
        }

        // Get all order details
        $orderDetails = $this->transJualDetModel->where('id_penjualan', $invoiceId)->findAll();
        
        if (empty($orderDetails)) {
            session()->setFlashdata('error', 'No tickets found for this order');
            return redirect()->to('admin/transaksi/sale/detail/' . $invoiceId);
        }

        // Get user info
        $user = null;
        if ($order->user_id) {
            $user = $this->ionAuth->user($order->user_id)->row();
        }

        try {
            // Create a combined PDF with all tickets
            $pdf = new \TCPDF('L', 'mm', array(210, 148.5), true, 'UTF-8', false);
            $pdf->SetCreator('WGTIX System');
            $pdf->SetAuthor('WGTIX Event Management');
            $pdf->SetTitle('Event Tickets - Invoice #' . $order->invoice_no);
            $pdf->SetMargins(0, 0, 0);
            $pdf->SetAutoPageBreak(FALSE);

            foreach ($orderDetails as $orderDetail) {
                // Event info
                $event = (object)[
                    'title' => $orderDetail->event_title ?: 'Event',
                    'date' => $order->invoice_date,
                    'location' => 'Event Venue'
                ];

                // Create individual ticket
                $ticket = new TicketPdf($orderDetail, $order, $user, $event);
                $ticketContent = $ticket->generateTicket();
                
                // Import the ticket page into combined PDF
                $pdf->AddPage();
                $pdf->writeHTML('<div style="page-break-after: always;"></div>', true, false, true, false, '');
            }
            
            // Set headers for PDF download
            $filename = 'All_Tickets_' . $order->invoice_no . '_' . date('Y-m-d') . '.pdf';
            
            return $this->response
                ->setHeader('Content-Type', 'application/pdf')
                ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
                ->setHeader('Cache-Control', 'private, max-age=0, must-revalidate')
                ->setHeader('Pragma', 'public')
                ->setBody($pdf->Output('S'));
                
        } catch (\Exception $e) {
            log_message('error', 'All tickets generation failed for invoice ' . $invoiceId . ': ' . $e->getMessage());
            session()->setFlashdata('error', 'Failed to generate tickets: ' . $e->getMessage());
            return redirect()->to('admin/transaksi/sale/detail/' . $invoiceId);
        }
    }

    /**
     * Generate QR codes for all order details when payment is marked as paid
     */
    private function generateQRCodesForOrder($invoiceId)
    {
        try {
            // Get all order details for this invoice
            $orderDetails = $this->transJualDetModel->where('id_penjualan', $invoiceId)->findAll();
            
            if (empty($orderDetails)) {
                log_message('warning', "No order details found for invoice ID: {$invoiceId}");
                return false;
            }

            // Create directory structure for QR codes
            $qrDirectory = FCPATH . 'file/sale/' . $invoiceId . '/qrcode/';
            if (!is_dir($qrDirectory)) {
                if (!mkdir($qrDirectory, 0755, true)) {
                    log_message('error', "Failed to create QR directory: {$qrDirectory}");
                    return false;
                }
            }

            foreach ($orderDetails as $detail) {
                // Remove existing QR code file if it exists
                if (!empty($detail->qrcode)) {
                    $oldFilePath = $qrDirectory . $detail->qrcode;
                    if (file_exists($oldFilePath)) {
                        unlink($oldFilePath);
                        log_message('info', "Removed existing QR code: {$detail->qrcode}");
                    }
                }
                
                // Generate QR content - using detail ID and timestamp
                $qrContent = $detail->id . '|' . $invoiceId . '|' . date('Y-m-d H:i:s');
                
                // Generate unique filename
                $fileName = 'qr_' . $detail->id . '_' . time() . '.png';
                $filePath = $qrDirectory . $fileName;
                
                // Create QR code
                $qrCode = new QrCode($qrContent);
                $writer = new PngWriter();
                $result = $writer->write($qrCode);
                
                // Save QR code to file (overwrite if exists)
                if (file_put_contents($filePath, $result->getString())) {
                    // Update database with QR filename
                    $this->transJualDetModel->update($detail->id, [
                        'qrcode' => $fileName,
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);
                    
                    log_message('info', "QR code generated for order detail ID: {$detail->id}, file: {$fileName}");
                } else {
                    log_message('error', "Failed to save QR code file: {$filePath}");
                }
            }
            
            return true;
            
        } catch (\Exception $e) {
            log_message('error', "QR code generation failed for invoice {$invoiceId}: " . $e->getMessage());
            return false;
        }
    }
}
