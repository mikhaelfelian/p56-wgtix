<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        Version <?= env('app.version') ?>
    </div>
    <strong>Copyright &copy; <?= date('Y') ?> <a href="<?= base_url() ?>"><?= $Pengaturan->judul_app ?></a>.</strong> All rights reserved.
</footer> 